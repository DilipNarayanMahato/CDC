﻿namespace Razor_syntax.Services
{
    public interface IMathService
    {
        int Add(int a, int b);
    }
}
