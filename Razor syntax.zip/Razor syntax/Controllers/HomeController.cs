using Microsoft.AspNetCore.Mvc;
using Razor_syntax.Models;
using Razor_syntax.Services;
using System.Diagnostics;

namespace Razor_syntax.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IMathService _mathService;

        // Single constructor with both dependencies
        public HomeController(ILogger<HomeController> logger, IMathService mathService)
        {
            _logger = logger;
            _mathService = mathService;
        }

        // Rest of your actions (Index, Privacy, StudentInfo, etc.)
        public IActionResult Index()
        {
            int result = _mathService.Add(10, 20);
            ViewBag.MathResult = result;
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult StudentInfo()
        {
            // Sample list of students
            var students = new List<Student>
            {
                new Student { Name = "John Doe", Roll = 10, Marks = 75 },
                new Student { Name = "Jane Smith", Roll = 20, Marks = 85 },
                new Student { Name = "Sam Brown", Roll = 30, Marks = 45 },
                new Student { Name = "Alice Johnson", Roll = 40, Marks = 95 },
                new Student { Name = "Bob White", Roll = 50, Marks = 49 }
             };

            return View(students); // Pass the list to the view
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
