﻿namespace Razor_syntax.Models
{
    public class Student
    {
        public string Name { get; set; }
        public int Roll { get; set; }
        public int Marks { get; set; }
    }
}